
<?php $__env->startPush('styles'); ?>
    <style>
        .navbar-light .navbar-nav .nav-link {
          color: black;
          font-size: 15px;
          font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-nav.navbar-center {
            position: absolute;
            left: 30%;
            transform: translatex(-10%);
        }
        body.modal-open .modal {
          display: flex !important;
          height: 100%;
      } 

      body.modal-open .modal .modal-dialog {
          margin: auto;
      }
      .form-control{
        border-color: #B78B1E;
      }
      textarea:focus, input:focus, input[type]:focus {
        border-color: #B78B1E;
        box-shadow: 0 1px 1px #e4c020 inset, 0 1px 8px #e4c020;
        outline: 0 none;
      }
      #email::placeholder{
        color:black;
      }

      #password::placeholder{
        color:black;
      }


    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('menu'); ?>
<nav class="navbar navbar-expand-lg navbar-light " >
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
          <img style="width:50px;" src='<?php echo e(asset("images/Isotipo-3.png")); ?>'>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" style="filter: invert(100%);" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 navbar-center" style="margin-left: 30px;text-align: center;" data-animation="center">
          <li class="nav-item">
            <a class="nav-link " aria-current="page" href="<?php echo e(url('/objetivo')); ?>" style="padding-right: 25px;">Objetivo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" style="padding-right: 25px;">Propiedades</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="<?php echo e(url('/nuestra_moneda')); ?>" style="padding-right: 25px;"  aria-disabled="true">Nuestra Moneda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="<?php echo e(url('/contactar_agente')); ?>" style="padding-right: 25px;"  aria-disabled="true">Contactar Agente</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="<?php echo e(url('/vender_propiedad')); ?>" style="padding-right: 25px;"  aria-disabled="true">Vender Propiedad</a>
          </li>
          <li class="nav-item">
            <?php if(Auth::check()): ?>
            <div class="dropdown mt-3">
              <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style="color:black;font-size:12px">
                <?php echo e(Auth::user()->name); ?>

              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <li><a class="dropdown-item" href="<?php echo e(url('/salir')); ?>">SALIR</a></li>
              </ul>
            </div>
            <?php else: ?>
            <a type="button" class="btn nav-link mt-1" style="color:black" data-bs-toggle="modal" data-bs-target="#exampleModal">
              Ingresar
            </a>
            <?php endif; ?>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  
    <main>
      <div id="colorlib-main">
		  	<div class="colorlib-contact">
		  		<div class="container-fluid">
		  			<!-- titulo -->
            <div class="row">
		  				<div class="col-md-12">
		  					<h1 class="animate-box fadeInLeft animated" data-animate-effect="fadeInLeft">
                    <?php echo $__env->yieldContent('title'); ?>
                </h1>
		  				</div>
		  			</div>
                 <!-- body -->
                 <?php echo $__env->yieldContent("body"); ?>
	    			</div>
	    		</div>
	    	</div>
	    </div>
    </main> 
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\los-santos\resources\views/layouts/nav_black.blade.php ENDPATH**/ ?>