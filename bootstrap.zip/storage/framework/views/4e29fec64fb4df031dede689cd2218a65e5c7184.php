
<?php $__env->startPush('styles'); ?>
    <style>
        /* body,html{
            background-image: url('images/background.jpg');
            background-position: center;
            background-repeat:no-repeat; 
            background-size: cover; 
            height: 100%;
            width: 100%;
            overflow-x: hidden;
        } */
        #colorlib-main {
          float:none;
          width: 100%;
        }
        footer {
         position: fixed;
         bottom: 25px;            
        }
        @font-face{
            font-family: 'Kinlock Regular';
            src:url('css/FontsFree-Net-ps-kinlock-regular.ttf') format('truetype');
            font-style: normal;
            font-weight: normal;
        }
        @font-face{
          font-family: 'Avenir Next Condensed';
          src:url('css/Avenir Next Condensed.ttc') format('truetype');
          font-style: normal;
          font-weight: normal;
        }
        .zoom {
            transition: transform .2s; 
            height:400px;
            width:360px;
            filter: grayscale(100%);
        }

        .zoom:hover {
            transform: scale(1.2); 
            filter:brightness(100%);
            opacity:1;
        }
        .img{
          height: 280px;
          width: 100%;
        }
        .swiper {
          width: 100%;
          height:100%;
        }
        .swiper-slide{
          width: 358px !important;
        }
        .form-control {
          border: 2px solid #B78B1E;
        }
        .colorlib-blog, .colorlib-work, .colorlib-about, .colorlib-services, .colorlib-contact {
          padding-top: 0em;
          padding-bottom: 0em;
          clear: both;
          width: 100%;
          display: block;
        }
        #caja4{box-shadow: 10px 10px 30px 6px gray;}

        .diseño{
          box-shadow: 0px 0px 30px 15px rgb(80, 73, 73);
        }

        .words{
          word-break: break-all;
          text-decoration: none;
          color:black;
        }

        
        
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-md-12" style="text-align:center">
        <a style="font-family:Avenir Next Condensed;font-size:60px;"> JOYERÍA</a>
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-4"></div>
    <div class="col-md-4" style="text-align: center;">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <select name="cantidad" id="cantidad" class="form-control" style="text-align:center">
                    <option value="25">25 Santos</option>
                </select>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
    <div class="col-md-4"></div>
</div>
<div class="row">
    <div class="swiper" >
      <div class="swiper-wrapper">

          <?php $__currentLoopData = $ropas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ropa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="swiper-slide" style="width: 380px !important;">
            <div class="card zoom">
              <a onclick="modal(<?php echo e($ropa->id); ?>)">
                <img src='<?php echo e($ropa->imagen); ?>' class=" img-fluid img">
              </a>
              <div class="card-body">
                <h5 class="card-title" style="font-family:Avenir Next Condensed;font-weight:bold"><?php echo e($ropa->nombre); ?></h5>
                <p class="card-text" style="font-family:Avenir Next Condensed;"><?php echo e(number_format($ropa->precio,2)); ?> SANTOS</p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!-- Add Pagination -->
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
    </div>
</div>
<div class="row">
  <div class="col-md-12" style="text-align:center">
    <a href="<?php echo e(url('/carrito')); ?>" style="color:black;font-size:25px;text-decoration: none;">VER CARRITO DE COMPRA</a>
  </div>
</div>
<div class="row" style="text-align:center;background-color:white">
    <div class="col-md-12">
      <img src='<?php echo e(asset("images/Isotipo-3.png")); ?>' alt="" style="height: 70px;">
    </div>
</div>

<form id="count_products">
  <?php echo csrf_field(); ?>
  <!-- Modal --> 
  <div class="modal bd-example-modal-xl" id="myModal" tabindex="-1" role="dialog" aria-labelledby="mmyExtraLargeModalLabel" aria-hidden="true" >
    <div class="modal-dialog modal-xl diseño">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" style="font-family:Avenir Next Condensed;font-size:25px" id="titulo_modal"></h5>
            <button type="button" class="btn-close" onclick="closeModal();"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-6">
              <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6" id="caja4">
                  <img class="img-fluid" id= "modal-imagen" style="height: 380px !important;width:100%" >
                </div>
                <div class="col-md-1"></div>
              </div>
            </div>
            <div class="col-md-5">
                <div class="row">
                  <div class="col-md-12 mt-3" style="line-height: 1;">
                    <a style="font-family:Avenir Next Condensed;font-size:25px" id="nombre_ropa"></a>
                  </div>
                  <div class="col-md-12">
                    <a style="font-family:Avenir Next Condensed;font-size:20px;color:#B78B1E" id="santos"></a>
                  </div>
                  <div class="col-md-12 mt-2">
                    <a style="font-size:20px;font-family:Avenir Next Condensed;" id="modelo_ropa" class="words"></a>
                  </div>
                  <div class="col-md-12">
                    <a style="font-size:20px;font-family:Avenir Next Condensed;" id="genero">
                    </a>
                  </div>
                  <div class="col-md-12">
                    <a style="font-size:20px;font-family:Avenir Next Condensed;" id="color">
                    </a>
                  </div>
                  <div class="row mt-5 mb-4">
                    <div class="col-md-3">
                      <input id="cantidad" type="number" name="cantidad" value="0" min="0" class="form-control">
                    </div>
                    <div class="col-md-7">
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-md-1"></div>
          </div>
          <div class="row mb-5">
            <div class="col-md-6"></div>
            <div class="col-md-6">
              <button type="button" class="btn" style="background-color:white;color:black;display: contents;"><a href="#"><i style="font-size:2rem;color:#b78b1e" id="shopping-cart"  class="fas fa-shopping-cart"></i></a>Agregar al carrito</button>
            </div>
          </div>
        </div>
        <div class="modal-footer d-flex align-items-center">
          
        </div>
      </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">
      
      async function modal(id){
        let url = "<?php echo e(url('/datos/{id}')); ?>".replace('{id}',id);
        let req = await fetch(url);
        if (req.ok) {
        let data = await req.json();
        // console.log(data);
        document.getElementById("titulo_modal").innerHTML = "Categoría de Comprador/ Ropa y Accesorios/ " + parseFloat(data.precio).toFixed(2) + " Santos/ " + data.nombre
        document.getElementById("santos").innerHTML = parseFloat(data.precio).toFixed(0) + " SANTOS";
        document.getElementById("modal-imagen").src = data.imagen;
        document.getElementById("nombre_ropa").innerHTML = data.nombre;
        document.getElementById("modelo_ropa").innerHTML = "Modelo: " + data.modelo_ropa;
        document.getElementById("genero").innerHTML =  data.genero_reloj;
        document.getElementById("color").innerHTML = "Color: " + data.color;

        // var modal = document.getElementById('')
        $("#myModal").toggle();

        }
        // .then(response => {
        //   let data = response.json();
        //   document.getElementById("modal-imagen").src = data.imagen;
        //   $("myModal").show();
        // })
      }
function closeModal() {
  $("#myModal").toggle();
}
    var swiper = new Swiper('.swiper', {
      slidesPerView: 3,
      pagination: {
        el: '.swiper-pagination',
        type: 'fraction',
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.nav_black', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\los-santos\resources\views/productos/ropa.blade.php ENDPATH**/ ?>