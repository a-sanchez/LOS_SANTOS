@extends('layouts.nav_black')
@push('styles')
    <style>
         #colorlib-main {
          float:none;
          width: 100%;
        }
        .border {
          border: 3px solid #b0831e !important;
        }
        .border_bajo{
            border-bottom:3px solid #b0831e !important;
        }
        @font-face{
            font-family: 'Kinlock Regular';
            src:url('css/FontsFree-Net-ps-kinlock-regular.ttf') format('truetype');
            font-style: normal;
            font-weight: normal;
        }
        @font-face{
          font-family: 'Avenir Next Condensed';
          src:url('css/Avenir Next Condensed.ttc') format('truetype');
          font-style: normal;
          font-weight: normal;
        }
        .diseño{
            box-shadow: 1px 1px 26px 2px rgba(80, 73, 73, 0.67);
        }
    </style>
@endpush
@section('body')
<div class="row" style="border-color:black">
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div class="row border">
            <div class="col-md-12 mt-2">
                <div class="row mt-3 ms-3 me-3 mb-3 diseño">
                    <div class="col-md-12">
                        <div class="row mt-5 ms-3 me-3 mb-3">
                            <div class="col-md-12">
                                <a href="#" style="text-decoration: none;color: black;font-size: 30px;font-family: 'Avenir Next Condensed';"><i style="font-size:2rem;color:#b78b1e" id="shopping-cart"  class="fas fa-shopping-cart"></i> Carrito de Compra </a>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row mt-5">
                                        <div class="col-md-5">
                                            <img src="{{asset("images/Isotipo-1.png")}}" class="img-fluid">
                                        </div>
                                        <div class="col-md-7" style="align-content: center;display: flex;">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h4 style="font-family: 'Avenir Next Condensed';font-weight: bolder;">Vuelo a Cancún</h4>
                                                </div>
                                                <div class="col-md-12">
                                                    <h5 style="color:#b78b1e">4,300 SANTOS</h5>
                                                </div>
                                                <div class="col-md-12 mt-2"></div>
                                                <div class="col-md-12">
                                                    <h5 style="font-size:18px">Vuelo Redondo</h5>
                                                </div>
                                                <div class="col-md-12">
                                                    <h5 style="font-size:18px">Fechas:15 Junio - 25 Junio</h5>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3"></div>
                                <div class="col-md-3" style="align-items: center;display:flex;">
                                    <div class="row">
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6">
                                            <input id="cantidad" type="number" name="cantidad" value="0" min="0" class="form-control">
                                        </div>
                                        <div class="col-md-3"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10"></div>
                                <div class="col-md-2">
                                    <div class="row mb-1">
                                        <div class="col-md-12">
                                            <h5 style="font-size:18px;color:#b78b1e;float: right;">Total Santos</h5>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-12 border_bajo">
                                            <h5 class="mb-3" style="font-size:18px;float: right;">cantidad</h5>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-md-12">
                                            <a href="#" style="font-size:20px;color:#b78b1e;float: right;font-weight:bolder;text-decoration:none">CONTINUAR</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4" style="text-align:center">
            <div class="col-md-12">
                <a href="{{url('/')}}" style="color:black;text-decoration:none;font-size:20px">SEGUIR COMPRANDO</a>
            </div>
        </div>
    </div>
    <div class="col-md-1"></div>
</div>
@endsection
@push('scripts') 
@endpush