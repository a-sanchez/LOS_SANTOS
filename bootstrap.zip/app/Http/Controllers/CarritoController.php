<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CarritoController extends Controller
{
    public function index(){
        $cartItems = \Cart::getContent();
        return view('cart.cart',compact('cartItems'));
    }
    // public function cartList(){
    //     $cartItems = \Cart::getContent();
    //     return view('cart.cart',compact('cartItems'));
    // }

    public function store(Request $request){
        $validation =$request->all();
        $orden = ordenes::create($validation);
        return response()->json("El producto se agrego al carrito");
    }

    public function updateCart(Request $request){
        \Cart::update(
            $request->id,
            [
                'quantity' => [
                    'relative' => false,
                    'value' => $request->quantity
                ],
            ]);
        session()->flash('success','El producto se ha actualizado');
        return redirect()->route('cart.list');
    }
    public function removeCart(Request $request){
        \Cart::remove($request->id);
        session()->flash('success','Producto eliminado correctamente');
        return redirect()->route('cart.list');
    }
    public function clearAllCart(){
        \Cart::clear();
        session()->flash('success','Se ha borrado el carrito');
        return redirect()->route('cart.list');
    }
}
